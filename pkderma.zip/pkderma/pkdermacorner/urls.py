from django.urls import include, path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('register', views.register, name='register'),
    path('login', views.login, name='login'),
    path('logout', views.logout, name='logout'),
    path('deleteacc', views.deleteacc, name='deleteacc'),
    path('profile', views.profile, name='profile'),
    path('blog', views.blog, name='blog'),
    path('post', views.post, name='post'),
    path('delpost/(?P<pstid>\d+)', views.delpost, name='delpost'),
    path('editpost/(?P<pstid>\d+)', views.editpost, name='editpost'),
    path('appointment', views.appointment, name='appointment'),
    path("sampleFile", views.sample_file_upload, name='file'),

]