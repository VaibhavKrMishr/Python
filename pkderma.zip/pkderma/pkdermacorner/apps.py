from django.apps import AppConfig


class PkdermacornerConfig(AppConfig):
    name = 'pkdermacorner'
