from django import forms
# from uploads.core.models import Document
from .models import Post

class BlogForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ['thumbnail']