from django.db import models

class Post(models.Model):
    author = models.CharField(max_length=50)
    email = models.EmailField()
    title = models.CharField(max_length=100)
    blogpost = models.TextField(models.TextField)
    timestamp = models.DateTimeField(auto_now_add=True)
    comment_count = models.IntegerField(default=0)
    category = models.CharField(max_length=20)
    thumbnail = models.ImageField(upload_to="pics/")#, default="pics/blogthumb.png")

    class Admin:
        pass
    
    def __str__(self):
        return self.title

class Appointment(models.Model):
    ptname = models.CharField(max_length=20)
    email = models.EmailField()
    subject = models.CharField(max_length=50)
    message = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    class Admin:
        pass

    def __str__(self):
        return self.ptname

# class Files(models.Model):
#     document = models.FileField(upload_to="documents")

#     def __str__(self):
#         return self.document