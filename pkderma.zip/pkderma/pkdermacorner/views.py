from django.http import HttpResponse, HttpRequest
from django.shortcuts import render, redirect, get_object_or_404, HttpResponseRedirect
from django.contrib import messages
from django.contrib.auth.models import User, auth
from .models import Post, Appointment
from .forms import BlogForm
import os
from pkderma import settings

def home(request):
    print(request.path)
    url_path = request.path
    url_file = open("pkdermacorner/url_file.dat", 'w+')
    url_file.write(url_path)
    url_file.close()
    
    latest = Post.objects.order_by('-timestamp')[0:3]
    context = {
        'latest': latest    
    }
    return render(request, "home.html", context)

def register(request):
    if request.method == 'POST':
        first_name = request.POST['first_name']
        last_name = request.POST['last_name']
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        if password1 == password2:
            if User.objects.filter(username=username).exists():
                messages.info(request, "Username taken!")
                return redirect('register')
            elif User.objects.filter(email=email).exists():
                messages.info(request, "Email Taken!")
                return redirect('register')
            else:
                user = User.objects.create_user(first_name = first_name, last_name = last_name, username = username, password=password1, email=email)
                user.save()
                print("User Created")
                return redirect('login')
        else:
            messages.info(request, "Password not matching!")
            return redirect('register')
        return redirect('/')

    else:
        return render(request, 'register.html')


def login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            url_file = open("pkdermacorner/url_file.dat", 'r')
            print(url_file.tell())
            line = url_file.readline()
            print(line)
            url_file.close()
            if line is None:
                return redirect('/')
            else:
                return redirect(line)
        else:
            messages.info(request, "Invalid Credentials!")
            return redirect('login')
    else:
        return render(request, 'login.html')


def logout(request):
    auth.logout(request)
    return redirect('/')


def deleteacc(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            user.delete()
            return redirect('/')
        else:
            messages.info(request, "Invalid Credentials!")
            return redirect('deleteacc')
    else:
        return render(request, 'deleteacc.html')
        

def blog(request):
    print(request.path)
    url_path = request.path
    url_file = open("pkdermacorner/url_file.dat", 'w+')
    url_file.write(url_path)
    url_file.seek(0, 0)
    url_file.close()
    
    post = Post.objects.all()
    form = BlogForm()
    context = {
            'post': post,
            'form': form
    }

    return render(request, 'blog.html', context)


def post(request):
        
    if request.method == 'POST':
        form = BlogForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            thumbnail = form.cleaned_data['thumbnail']
        else:
            thumbnail = os.path.join(settings.MEDIA_ROOT, 'pics/blogthumb.png')
        username = request.POST['username']
        email = request.POST['email']
        subject = request.POST['subject']        
        category = request.POST['category']
        message = request.POST['message']
        #
        new_post = Post()
        new_post.author = username
        new_post.email = email
        new_post.category = category        
        new_post.title = subject
        new_post.blogpost = message
        new_post.thumbnail = thumbnail
        new_post.save()
        
        post = Post.objects.all()
        context = {
            'post': post,        
            'form': form
        }
        return render(request, 'blog.html', context)
        # return redirect('blog')
    else:
        return redirect('blog')
        
def delpost(request, pstid):
    pstid = int(pstid)
    print("Hello")
    
    new_post = Post.objects.filter(id = pstid)
    print(new_post)
    new_post.delete()
    return redirect('blog')
    
def editpost(request, pstid):
    pstid = int(pstid)
    print(pstid)
    new_post = Post.objects.filter(id = pstid)
    print(new_post)
    
    if request.method == 'POST':
        print('posts')
        username = request.POST['username']
        email = request.POST['email']
        subject = request.POST['subject']        
        category = request.POST['category']
        message = request.POST['message']
        edit_post = Post.objects.get(id = pstid)
        edit_post.author = username
        edit_post.email = email
        edit_post.category = category        
        edit_post.title = subject
        edit_post.blogpost = message
        edit_post.save()

        return redirect('blog')

    else:
        context = {'new_post': new_post}
        return render(request, 'blogedit.html', context)

# def editpost2(request, pstid):
#     if request.method == 'POST':
#         username = request.POST['username']
#         email = request.POST['email']
#         subject = request.POST['subject']        
#         category = request.POST['category']
#         message = request.POST['message']
#         edit_post = Post()
#         edit_post.author = username
#         edit_post.email = email
#         edit_post.category = category        
#         edit_post.title = subject
#         edit_post.blogpost = message
#         edit_post.save()

def profile(request):
    pass

def appointment(request):
    if request.method == "POST":
        ptname = request.POST['name']
        email = request.POST['email']
        subject = request.POST['subject']
        message = request.POST['message']
        appoment = Appointment()
        appoment.ptname = ptname
        appoment.email = email
        appoment.subject = subject
        appoment.message = message
        appoment.save()
        print("SAVED")
        
        return redirect('appointment')

    else:
        appment = Appointment.objects.order_by("-timestamp")
        context = {
            'appment': appment
        }
        return render(request, 'appointment.html', context)
        # return redirect('home')

def sample_file_upload(request):
    if request.method =="POST":
        form = BlogForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = BlogForm()
    return render(request, 'sample_file_upload.html', {'form': form})